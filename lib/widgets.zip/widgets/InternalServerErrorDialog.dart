import 'package:flutter/material.dart';

class InternalServerErrorDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Internal Server Error'),
      content: Text('Sorry, there was an internal server error. Please try again later.'),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('OK'),
        ),
      ],
    );
  }
}

void showInternalServerErrorDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return InternalServerErrorDialog();
    },
  );
}
