import 'package:flutter/material.dart';
import 'package:colleage_thriver/core/app_export.dart';
import 'package:colleage_thriver/presentation/home_screen/controller/home_screen_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:velocity_x/velocity_x.dart';
import '../custom_icon_button.dart';
import 'appbar_title.dart';


PreferredSizeWidget appbarHomepage(BuildContext context) {
  HomePageCollegeController homePageCollegeController =Get.find<HomePageCollegeController>();


    return PreferredSize(
        preferredSize: Size.fromHeight(70.v), // preferred height for the app bar
        child: SafeArea(
          child: Column(
            children: [
              5.v.heightBox,
              Container(
                height: 64.v,
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      CustomImageView(
                          imagePath: ImageConstant.imgRectangle593,
                          height: 49.v,
                          width: 46.h),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "lbl_college".tr,
                            style: CustomTextStyles.titleMediumBlack90001.copyWith(
                              color: appTheme.black90001,
                            ),
                          ),Text(
                            "lbl_thriver".tr,
                            style: CustomTextStyles.titleMediumBlack90001.copyWith(
                              color: appTheme.black90001,
                            ),
                          ),
                        ],
                      ),
                      CustomImageView(
                        onTap: () {
                          Get.offAllNamed(AppRoutes.homeScreen);
                        },
                        imagePath: ImageConstant.imgRoadmap21,
                        height: 46.v,
                      ),
                      InkWell(
                        onTap: () {
                          Get.toNamed(AppRoutes.topStudentsOneScreen);
                        },
                        child: Container(
                          height: 48.v,
                          width: 48.v,
                          decoration: BoxDecoration(
                              color: Color(0xffEEEEEE),
                              borderRadius: BorderRadius.circular(60)),
                          child: Center(child:  CustomImageView(
                            imagePath: ImageConstant.imgSearch,
                            height: 30.v,
                            width: 30.v,
                            color: theme.colorScheme.primary,
                          ),),),
                      ),

                      GestureDetector(
                        onTap: () {
                          Get.toNamed(
                            AppRoutes.tellUsAboutYourselfScreen,
                          );
                        },
                        child: Obx(
                            ()=> CustomImageView(
                              radius: BorderRadius.circular(50.adaptSize),
                              fit: BoxFit.fill,
                              imagePath: homePageCollegeController.profiePic.value,
                              height: 50.adaptSize,
                              width: 50.adaptSize),
                        ),
                      ),
                      CustomImageView(
                        onTap: () {
                          showModalBottomSheet(
                            context: context,
                            builder: (BuildContext context) {
                              return _bottomsheetWidget();
                            },
                          );
                        },
                        imagePath: ImageConstant.imgMegaphone,
                        color: theme.colorScheme.primary,
                        height: 30.v,),
                    ],
                  ),
                ),
              ),

            ],
          ),
        ));
}

AppBar myAppbar({ required String  title}) {
  return AppBar(
      leadingWidth: 32.h,
      backgroundColor: Colors.white,
      elevation: .5,
      title: AppbarTitle(
          text: title.tr,
          margin: EdgeInsets.only(left: 10.h)),
  );
}

_bottomsheetWidget(){
  return Padding(
    padding: const EdgeInsets.all(20.0),
    child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
              onTap: () {
                Get.back();
              },
              child: Row(children: [
                CustomIconButton(
                    height: 42.adaptSize,
                    width: 42.adaptSize,
                    padding: EdgeInsets.all(5.h),
                    decoration: IconButtonStyleHelper.fillGrayTL19,
                    child: CustomImageView(
                        imagePath: ImageConstant.imgEdit38x38)),
                Padding(
                    padding: EdgeInsets.only(
                        left: 10.h, top: 10.v, bottom: 7.v),
                    child: Text("lbl_your_roadmap".tr,
                        style: CustomTextStyles
                            .bodyLargeInterBlack90001_1))
              ])),
          SizedBox(height: 22.v),

          // College Matches

          GestureDetector(
              onTap: () {
                Get.back();
                Get.toNamed(AppRoutes.recommendedCollegeScreen);
                // onTapFrame2();
              },
              child: Row(children: [
                CustomIconButton(
                    height: 42.adaptSize,
                    width: 42.adaptSize,
                    padding: EdgeInsets.all(11.h),
                    decoration: IconButtonStyleHelper.fillGrayTL19,
                    child: CustomImageView(
                        color: Colors.black,

                        imagePath: ImageConstant.imgUser)),
                Padding(
                    padding: EdgeInsets.only(
                        left: 10.h, top: 9.v, bottom: 8.v),
                    child: Text("College Matches".tr,
                        style: CustomTextStyles
                            .bodyLargeInterBlack90001_1))
              ])),
          SizedBox(height: 22.v),

         //Favorites
          GestureDetector(
              onTap: () {
                Get.back();
                Get.toNamed(AppRoutes.favoritesCollegeScreen);
              },
              child: Row(children: [
                CustomIconButton(
                    height: 42.adaptSize,
                    width: 42.adaptSize,
                    padding: EdgeInsets.all(11.h),
                    decoration: IconButtonStyleHelper.fillGrayTL19,
                    child: CustomImageView(
                        color: Colors.black,

                        imagePath: ImageConstant.imgUser)),
                Padding(
                    padding: EdgeInsets.only(
                        left: 10.h, top: 9.v, bottom: 8.v),
                    child: Text("College Favorites".tr,
                        style: CustomTextStyles
                            .bodyLargeInterBlack90001_1))
              ])),
          SizedBox(height: 22.v),



          GestureDetector(
              onTap: () {
                onTaptellUsAboutYourSchoolScreen();
              },
              child: Row(children: [
                CustomIconButton(
                    height: 42.adaptSize,
                    width: 42.adaptSize,
                    padding: EdgeInsets.all(10.h),
                    decoration: IconButtonStyleHelper.fillGrayTL19,
                    child: CustomImageView(
                        color: Colors.black,
                        imagePath: ImageConstant.imgEdit)),
                Padding(
                    padding: EdgeInsets.only(
                        left: 10.h, top: 9.v, bottom: 8.v),
                    child: Text("lbl_edit_account".tr,
                        style: CustomTextStyles
                            .bodyLargeInterBlack90001_1))
              ])),
          SizedBox(height: 22.v),
          GestureDetector(
              onTap: () {
                onTapFrame2();
              },
              child: Row(children: [
                CustomIconButton(
                    height: 42.adaptSize,
                    width: 42.adaptSize,
                    padding: EdgeInsets.all(11.h),
                    decoration: IconButtonStyleHelper.fillGrayTL19,
                    child: CustomImageView(
                        color: Colors.black,

                        imagePath: ImageConstant.imgUser)),
                Padding(
                    padding: EdgeInsets.only(
                        left: 10.h, top: 9.v, bottom: 8.v),
                    child: Text("lbl_edit_photo".tr,
                        style: CustomTextStyles
                            .bodyLargeInterBlack90001_1))
              ])),
          SizedBox(height: 22.v),
          GestureDetector(
              onTap: () {
                 onTapFrame3();
              },
              child: Row(children: [
                CustomIconButton(
                    height: 42.adaptSize,
                    width: 42.adaptSize,
                    padding: EdgeInsets.all(10.h),
                    decoration: IconButtonStyleHelper.fillGrayTL19,
                    child: CustomImageView(
                        color: Colors.black,
                        imagePath: ImageConstant.imgSettings)),
                Padding(
                    padding: EdgeInsets.only(
                        left: 10.h, top: 10.v, bottom: 7.v),
                    child: Text("lbl_logout".tr,
                        style: CustomTextStyles
                            .bodyLargeInterBlack90001_1))
              ]))
        ]),
  );
}

/// Navigates to the tellUsAboutYourSchoolScreen when the action is triggered.
onTaptellUsAboutYourSchoolScreen() {
  Get.toNamed(
    AppRoutes.tellUsAboutYourSchoolScreen,
  );
}

/// Navigates to the tellUsAboutYourselfScreen when the action is triggered.
onTapFrame2() {
  Get.toNamed(
    AppRoutes.tellUsAboutYourselfScreen,
  );
}

/// Navigates to the loginScreen when the action is triggered.
onTapFrame3() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
   prefs.setBool('isLoggedIn',false);
  Get.offAllNamed(AppRoutes.loginScreen,);
}