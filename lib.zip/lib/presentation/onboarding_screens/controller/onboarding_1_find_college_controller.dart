import 'package:flutter/cupertino.dart';
import 'package:colleage_thriver/core/app_export.dart';

/// A controller class for the Onboarding1FindCollegeScreen.
///
/// This class manages the state of the Onboarding1FindCollegeScreen, including the
/// current onboarding1FindCollegeModelObj
class Onboarding1FindCollegeController extends GetxController {


  final PageController pageController =PageController();



}
