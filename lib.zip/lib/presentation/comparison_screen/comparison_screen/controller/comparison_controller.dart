
import 'package:get/get.dart';

/// A controller class for the ComparisonScreen.
///
/// This class manages the state of the ComparisonScreen, including the
/// current comparisonModelObj
class ComparisonController extends GetxController {
}