/// This class defines the variables used in the [meet_counselor_or_advisor_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class MeetCounselorOrAdvisorModel { }
