class AppUrls{
  AppUrls._();
  //MAIN

  // static const String mainUrl = "http://34.48.5.10:4000/";
  static const String mainUrl = "https://www.collegethriverapp.org:4000/";


  //locaL
  
   //static const String mainUrl = "http://192.168.29.100:4000/";

  static const String login = "login";
  static const String loginWithGoogle = "google-login";

  static const String forgetPassword = "forget-password";
  static const String signup = "signup";
  static const String viewProfile = "viewprofile";
  static const String homePage = "reward";
  static const String deletAccount = "delete";
  //http://34.48.5.10:4000/delete
  static const String updateProfile = "update";
  static const String updateProfileImage = "$mainUrl"+"uploadprofile";


  //1_of_5

   //college_01_of_05
  static const String collegeMatchOne = "college-match-one";
  static const String collegeMatchTwo = "college-match-two";
  static const String collegeMatchThree = "college-match-three";
  static const String collegeMatchFour = "college-match-four";

  //2_of_5
  static const String college_2_of_05 = "college-screen-one";
  static const String college_3_of_05 = "college-screen-ClgCampus";
  static const String college_4_of_05 = "college-screen-three";
  static const String college_5_of_05 = "college-screen-commitmentLetter";



  // college-match-all

  static const String getCollegeMatchAll = "college-match-all";
  static const String getTopStudents = "top-student";
  static const String allCollege = "all-college";
  static const String collegeSearch = "collegeSearch";


  static const String getFavCollege = "get-fav-college";


//scholar  5 apis
  static const String scholar_01 = "pandding";
  static const String scholar_02 = "scholar-shortlist";
  static const String scholar_03 = "scholar-apply";
  static const String scholar_04 = "scholar-collegeBoard";
  static const String scholar_05 = "scholar-fafsa";



  //chat

  static const String getMentors = "mentor-all";
  static const String chat_with_mentor = "chat_with_mentor/";
  static const String send_message = "send_message";
  static const String all_messages = "all_messages/";


}

